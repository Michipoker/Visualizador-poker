// script.js
function cambiarRango(ruta) {
    const imgElement = document.getElementById('rango-img');
    imgElement.src = ruta;
}